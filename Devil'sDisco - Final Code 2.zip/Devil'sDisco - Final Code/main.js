let form = document.getElementById('email-form');

function handleFormSubmit(event) {
    event.preventDefault();
    console.log(event);
}

form.addEventListener('submit', handleFormSubmit);